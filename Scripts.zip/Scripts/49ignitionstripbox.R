########################################################
#                                                      #
#   Author: Charles Minsavage-Davis                    #
#   Last edited: 02 July 2024                          #
#   Script for: Fuel management and traditional        #
#   managed burning reduce simulated landscape-scale   #
#   rates of spread and fireline intensities in        #
#   northern European heathlands                       #
#                                                      #
########################################################      

#Library for rstudio functions
install.packages ("rstudioapi")
library (rstudioapi)

#Getting the path of your current open file
current_path <- rstudioapi::getActiveDocumentContext()$path 
setwd(dirname(current_path))
print(getwd())

data <- read.csv("stack49graphNEW.csv", header = T)
#data2 <- read.csv("stack49graphreal.csv", header = T)

#Install and Load in requisite libraries
install.packages ("ggpubr")
install.packages ("nlme")
install.packages ("MASS")
install.packages ("rcompanion")
install.packages ("VGAM")
install.packages ("vegan")
install.packages ("ggplot2")
install.packages ("dplyr")
install.packages ("tidyr")
install.packages ("forcats")
install.packages ("hrbrthemes")
install.packages ("RColorBrewer")
install.packages ("car")
install.packages ("Rmisc")
install.packages ("Hmisc")
install.packages ("boot")
install.packages ("adonis")
install.packages ("car")
install.packages ("nlme")
install.packages ("EnvStats")
install.packages ("emmeans")
install.packages ("utils")
install.packages ("multcomp")
install.packages ("gghalves")
install.packages ("ggridges")
install.packages ("scales")
install.packages ("viridis")
install.packages ("ggtext")

library (ggpubr)
library (nlme)
library (MASS)
library (rcompanion)
library (VGAM)
library (vegan)
library (ggplot2)
library (dplyr)
library (tidyr)
library (forcats)
library (hrbrthemes)
library (RColorBrewer)
library (car)
library (Rmisc)
library (Hmisc)
library (boot)
#library (adonis)
library (car)
library (nlme)
library (EnvStats)
library (emmeans)
library (utils)
library (multcomp)
library (gghalves)
library (ggridges)
library (scales)
library (viridis)
library (ggtext)

##GLMS and EMMEANS

allspread <- data[data$ROSmean > 0, ]
hist(allspread$ROSmean)
hist(log(allspread$ROSmean))

ROSmean.ig <- glm(ROSmean~LCP*Wind*Moisture, data = allspread, family = inverse.gaussian)
Anova(ROSmean.ig)
summary(ROSmean.ig)

rosqq <- qqnorm(residuals(ROSmean.ig))
head(rosqq)
qqline(residuals(ROSmean.ig))
hist(residuals(ROSmean.ig))
head(residuals(ROSmean.ig))

emmip(ROSmean.ig, LCP ~ Wind | Moisture)
ROSmean.emm <- emmeans(ROSmean.ig, pairwise ~ LCP | Wind*Moisture)

FImean.ig <- glm(Fimean~LCP*Wind*Moisture, data = allspread, family = inverse.gaussian)
Anova(FImean.ig)
summary(FImean.ig)

qqnorm(residuals(FImean.ig))
qqline(residuals(FImean.ig))
hist(residuals(FImean.ig))

emmip(FImean.ig, LCP ~ Wind | Moisture)
FImean.emm <- emmeans(FImean.ig, pairwise ~ LCP | Wind*Moisture)

ROSsd.ig <- glm(ROSstd~LCP*Wind*Moisture, data = allspread, family = inverse.gaussian)
Anova(ROSsd.ig)
summary(ROSsd.ig)

qqnorm(residuals(ROSsd.ig))
qqline(residuals(ROSsd.ig))
hist(residuals(ROSsd.ig))

emmip(ROSsd.ig, LCP ~ Wind | Moisture)
ROSsd.emm <- emmeans(ROSsd.ig, pairwise ~ LCP | Wind*Moisture)

FIsd.ig <- glm(FIstd~LCP*Wind*Moisture, data = allspread, family = inverse.gaussian)
Anova(FIsd.ig)
summary(FIsd.ig)

qqnorm(residuals(FIsd.ig))
qqline(residuals(FIsd.ig))
hist(residuals(FIsd.ig))

emmip(FIsd.ig, LCP ~ Wind | Moisture)
FIsd.emm <- emmeans(FIsd.ig, pairwise ~ LCP | Wind*Moisture)

##LETTER Differences CLD

ROSmean.cld <- cld(ROSmean.emm$emmeans, alpha = 0.05, Letters = letters, adjust = "tukey")
FImean.cld <- cld(FImean.emm$emmeans, alpha = 0.05, Letters = letters, adjust = "tukey")
ROSsd.cld <- cld(ROSsd.emm$emmeans, alpha = 0.05, Letters = letters, adjust = "tukey")
FIsd.cld <- cld(FIsd.emm$emmeans, alpha = 0.05, Letters = letters, adjust = "tukey")

ROSmean.cld2 <- ROSmean.cld
ROSmean.cld2$LCP <- factor(ROSmean.cld2$LCP, levels = c("TM", "AM", "SFS", "MFS", "FE", "MFE", "RTM", "RFE"))
ROSmean.cld2 <- ROSmean.cld %>% arrange(Moisture, Wind, LCP)

FImean.cld2 <- FImean.cld
FImean.cld2$LCP <- factor(FImean.cld2$LCP, levels = c("TM", "AM", "SFS", "MFS", "FE", "MFE", "RTM", "RFE"))
FImean.cld2 <- FImean.cld %>% arrange(Moisture, Wind, LCP)

ROSsd.cld2 <- ROSsd.cld
ROSsd.cld2$LCP <- factor(ROSsd.cld2$LCP, levels = c("TM", "AM", "SFS", "MFS", "FE", "MFE", "RTM", "RFE"))
ROSsd.cld2 <- ROSsd.cld %>% arrange(Moisture, Wind, LCP)

FIsd.cld2 <- FIsd.cld
FIsd.cld2$LCP <- factor(FIsd.cld2$LCP, levels = c("TM", "AM", "SFS", "MFS", "FE", "MFE", "RTM", "RFE"))
FIsd.cld2 <- FIsd.cld %>% arrange(Moisture, Wind, LCP)

##permanova
#sqrtmros <- sqrt(meanros)
#qmeanros <- quantile(meanros)
#qmeanros

#lm <- lm(sqrtmros~lcp*ms*wind)
#hist(residuals(lm))
#qqnorm(residuals(lm))
#qqline(residuals(lm))

#vegdist(f.clean, method = "bray")

#meanros.dist <- dist(data$ROSmean)
#meanfi.dist <- dist(data$Fimean)
#sdros.dist <- dist(data$ROSstd)
#sdfi.dist <- dist(data$FIstd)

#perm.rosmean <- adonis2(meanros.dist~LCP*Moisture*Wind+LCP*Moisture+LCP*Wind+Moisture*Wind+LCP+Moisture+Wind, data = datanz, by = "margin")

#perm.fimean <- adonis2(meanfi.dist~LCP*Moisture*Wind+LCP*Moisture+LCP*Wind+Moisture*Wind+LCP+Moisture+Wind, data = datanz, by = "margin")

#perm.fimean <- adonis2(meanfi.dist~LCP*Moisture, strata = Wind, data = data, by = "margin")

#perm.rossd <- adonis2(sdros.dist~LCP*Moisture*Wind+LCP*Moisture+LCP*Wind+Moisture*Wind+LCP+Moisture+Wind, data = datanz, by = "margin")

#perm.fisd <- adonis2(sdfi.dist~LCP*LCP*Moisture*Wind+LCP*Moisture+LCP*Wind+Moisture*Wind+LCP+Moisture+Wind, data = datanz, by = "margin")

#Anova(perm.rosmean)
#perm.fimean
#perm.rossd
#perm.fisd

##mean

#meanrosAN <- Anova(lm(meanros ~ lcp*ms*wind), type = 2)

#Anova(lm(meanros ~ lcp*ms*wind, contrasts = list(lcp = contr.sum, ms = contr.sum, wind = contr.sum)), type = 3)

#Anova(lm(meanfi ~ lcp*ms*wind), type = 2)

#Anova(lm(meanfi ~ lcp*ms*wind, contrasts = list(lcp = contr.sum, ms = contr.sum, wind = contr.sum)), type = 3)

#hist(residuals(meanrosAN))
#qqnorm(residuals(log.ros.mean))
#qqline(residuals(log.ros.mean))

##max

##min

##SD

#CI95s

ROSMEANCI <- group.CI(ROSmean~LCP*Moisture*Wind, data, ci = 0.95)
FIMEANCI <- group.CI(Fimean~LCP*Moisture*Wind, data, ci = 0.95)
ROSSTDCI <- group.CI(ROSstd~LCP*Moisture*Wind, data, ci = 0.95)
FISTDCI <- group.CI(FIstd~LCP*Moisture*Wind, data, ci = 0.95)

ROSMINCI <- group.CI(ROSmin~LCP*Moisture*Wind, data, ci = 0.95)
FIMINCI <- group.CI(FImin~LCP*Moisture*Wind, data, ci = 0.95)
ROSMAXCI <- group.CI(ROSmax~LCP*Moisture*Wind, data, ci = 0.95)
FIMAXCI <- group.CI(FImax~LCP*Moisture*Wind, data, ci = 0.95)

write.csv(ROSMEANCI, file = "ROSMEANCI.csv")
write.csv(FIMEANCI, file = "FIMEANCI.csv")
write.csv(ROSSTDCI, file = "ROSSTDCI.csv")
write.csv(FISTDCI, file = "FISTDCI.csv")

write.csv(ROSMINCI, file = "ROSMINCI.csv")
write.csv(FIMINCI, file = "FIMINCI.csv")
write.csv(ROSMAXCI, file = "ROSMAXCI.csv")
write.csv(FIMAXCI, file = "FIMAXCI.csv")

#Strip and CONF Plots

data$LCP <- factor(data$LCP, levels = c("TM", "AM", "SFS", "MFS", "FE", "MFE", "RTM", "RFE"))
data$Moisture <- factor(data$Moisture, levels = c("Low", "Moderate", "High"))

show_col(viridis_pal(option = "magma")(20))

as.factor(data$Moisture)

rs.m.y <- expression("Mean Rate of Spread ( m"~min^-1~")")

bp.rs.m <- data %>%
    ggplot(aes(x = LCP, y = ROSmean, fill = Moisture)) +
#    geom_boxplot(fill = "black") +
    scale_fill_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    scale_color_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    #geom_half_point(aes(fill = Type), shape = 21, size = 2, side = "l") +
    geom_violin(aes(fill = Moisture), color = "black", alpha = 0.8 ) +
#    scale_color_brewer(palette = "Dark2") +
#    scale_fill_brewer(palette = "Dark2") +
    theme(panel.background = element_blank()) +
#    theme(legend.key = element_blank()) +
#    theme(legend.title = element_blank()) +
    xlab("Experimental Landscape") +
    ylab(rs.m.y) +
    labs(color = "", fill = "") +
#    ggtitle("\nMean Rate of Spread") +
    facet_grid(Moisture~Wind, labeller = label_both) +
    theme(legend.position = "bottom", legend.text = element_text(size = 15), legend.key.spacing = unit(10, "pt")) +
    theme(panel.grid.major = element_line(colour = "grey")) +
    theme(strip.background = element_rect(fill = "white")) +
    theme(strip.text = element_text(size = 16)) +
    #theme(plot.title = element_text(size = 30, face = "bold", hjust = 0.5, vjust = 1)) +
    theme(axis.title.x = element_text(size = 18, vjust = -0.5)) +
    theme(axis.title.y = element_text(size = 18, vjust = 1.5)) +
    annotate("segment", x = -Inf, xend = Inf, y = -Inf, yend = -Inf) +
    annotate("segment", x = -Inf, xend = -Inf, y = -Inf, yend = Inf) +
    theme(axis.text.x = element_text(color = c("black", "black", "black", "black", "black", "black", "darkblue", "darkblue"), size = 15),
    axis.text.y = element_text(color = "black", size = 15)) + 
    stat_summary(fun.data = mean_cl_boot, geom = "errorbar", colour = "black") + 
    stat_summary(fun = mean, geom = "point", size = 2, shape = 21, fill = "white", colour = "black") + 
    stat_summary(fun = max, colour = "white", size = 10, geom = "point", aes(y = max(ROSmean+.5), x = LCP), show.legend = FALSE) +
    stat_summary(geom = "text", fun = max, label = 
    c("CD", "A", "B", "B", "C", "E", "D", "CD", 
    "C", "A", "A", "A", "B", "D", "D", "C", 
    "C", "A", "B", "B", "C", "E", "D", "C",
    "D", "A", "AB", "B", "C", "E", "E", "D", 
    "C", "A", "B", "B", "CD", "F", "E", "D", 
    "CD", "A", "AB", "B", "C", "E", "E", "D"),
    aes(y = max(ROSmean+.5), x = LCP), position = "identity", colour = "red", size = 5) 

bp.rs.m

fi.m.y <- expression("Mean Fireline Intensity ( kw"~m^-1~")")

bp.fi.m <- data %>%
    ggplot(aes(x = LCP, y = Fimean, fill = Moisture)) +
#    geom_boxplot(fill = "black") +
    scale_fill_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    scale_color_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    #geom_half_point(aes(fill = Type), shape = 21, size = 2, side = "l") +
    geom_violin(aes(fill = Moisture), color = "black", alpha = 0.8 ) +
#    scale_color_brewer(palette = "Dark2") +
#    scale_fill_brewer(palette = "Dark2") +
    theme(panel.background = element_blank()) +
#    theme(legend.key = element_blank()) +
#    theme(legend.title = element_blank()) +
    xlab("Experimental Landscape") +
    ylab(fi.m.y) +
    labs(color = "", fill = "") +
#    ggtitle("\nMean Rate of Spread") +
    facet_grid(Moisture~Wind, labeller = label_both) +
    theme(legend.position = "bottom", legend.text = element_text(size = 15), legend.key.spacing = unit(10, "pt")) +
    theme(panel.grid.major = element_line(colour = "grey")) +
    theme(strip.background = element_rect(fill = "white")) +
    theme(strip.text = element_text(size = 16)) +
    #theme(plot.title = element_text(size = 30, face = "bold", hjust = 0.5, vjust = 1)) +
    theme(axis.title.x = element_text(size = 18, vjust = -0.5)) +
    theme(axis.title.y = element_text(size = 18, vjust = 1.5)) +
    annotate("segment", x = -Inf, xend = Inf, y = -Inf, yend = -Inf) +
    annotate("segment", x = -Inf, xend = -Inf, y = -Inf, yend = Inf) +
    theme(axis.text.x = element_text(color = c("black", "black", "black", "black", "black", "black", "darkblue", "darkblue"), size = 15),
    axis.text.y = element_text(color = "black", size = 15)) + 
    stat_summary(fun.data = mean_cl_boot, geom = "errorbar", colour = "black") + 
    stat_summary(fun = mean, geom = "point", size = 2, shape = 21, fill = "white", colour = "black") +
    stat_summary(fun = max, colour = "white", size = 10, geom = "point", aes(y = max(Fimean+500), x = LCP), show.legend = FALSE) +
    stat_summary(geom = "text", fun = max, label =
    c("C", "A", "AB", "B", "C", "E", "D", "C", 
    "BC", "A", "A", "A", "B", "E", "D", "C", 
    "C", "A", "B", "B", "C", "E", "D", "C",
    "CD", "A", "AB", "B", "C", "F", "E", "DE", 
    "C", "A", "B", "B", "CD", "F", "E", "D", 
    "C", "A", "AB", "B", "C", "E", "D", "D"),
    aes(y = max(Fimean+500), x = LCP), position = "identity", colour = "red", size = 5)

bp.fi.m

rs.mx.y <- expression("Maximum Rate of Spread ( m"~min^-1~")")

bp.rs.mx <- data %>%
    ggplot(aes(x = LCP, y = ROSmax, fill = Moisture)) +
#    geom_boxplot(fill = "black") +
    scale_fill_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    scale_color_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    #geom_half_point(aes(fill = Type), shape = 21, size = 2, side = "l") +
    geom_violin(aes(fill = Moisture), color = "black", alpha = 0.8 ) +
#    scale_color_brewer(palette = "Dark2") +
#    scale_fill_brewer(palette = "Dark2") +
    theme(panel.background = element_blank()) +
#    theme(legend.key = element_blank()) +
#    theme(legend.title = element_blank()) +
    xlab("Experimental Landscape") +
    ylab(rs.mx.y) +
    labs(color = "", fill = "") +
#    ggtitle("\nMean Rate of Spread") +
    facet_grid(Moisture~Wind, labeller = label_both) +
    theme(legend.position = "bottom", legend.text = element_text(size = 15), legend.key.spacing = unit(10, "pt")) +
    theme(panel.grid.major = element_line(colour = "grey")) +
    theme(strip.background = element_rect(fill = "white")) +
    theme(strip.text = element_text(size = 16)) +
    #theme(plot.title = element_text(size = 30, face = "bold", hjust = 0.5, vjust = 1)) +
    theme(axis.title.x = element_text(size = 18, vjust = -0.5)) +
    theme(axis.title.y = element_text(size = 18, vjust = 1.5)) +
    annotate("segment", x = -Inf, xend = Inf, y = -Inf, yend = -Inf) +
    annotate("segment", x = -Inf, xend = -Inf, y = -Inf, yend = Inf) +
    theme(axis.text.x = element_text(color = c("black", "black", "black", "black", "black", "black", "darkblue", "darkblue"), size = 15),
    axis.text.y = element_text(color = "black", size = 15)) + 
    stat_summary(fun.data = mean_cl_boot, geom = "errorbar", colour = "black") + 
    stat_summary(fun = mean, geom = "point", size = 2, shape = 21, fill = "white", colour = "black")

bp.rs.mx

fi.mx.y <- expression("Maximum Fireline Intensity ( kw"~m^-1~")")

bp.fi.mx <- data %>%
    ggplot(aes(x = LCP, y = FImax, fill = Moisture)) +
#    geom_boxplot(fill = "black") +
    scale_fill_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    scale_color_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    #geom_half_point(aes(fill = Type), shape = 21, size = 2, side = "l") +
    geom_violin(aes(fill = Moisture), color = "black", alpha = 0.8 ) +
#    scale_color_brewer(palette = "Dark2") +
#    scale_fill_brewer(palette = "Dark2") +
    theme(panel.background = element_blank()) +
#    theme(legend.key = element_blank()) +
#    theme(legend.title = element_blank()) +
    xlab("Experimental Landscape") +
    ylab(fi.mx.y) +
    labs(color = "", fill = "") +
#    ggtitle("\nMean Rate of Spread") +
    facet_grid(Moisture~Wind, labeller = label_both) +
    theme(legend.position = "bottom", legend.text = element_text(size = 15), legend.key.spacing = unit(10, "pt")) +
    theme(panel.grid.major = element_line(colour = "grey")) +
    theme(strip.background = element_rect(fill = "white")) +
    theme(strip.text = element_text(size = 16)) +
    #theme(plot.title = element_text(size = 30, face = "bold", hjust = 0.5, vjust = 1)) +
    theme(axis.title.x = element_text(size = 18, vjust = -0.5)) +
    theme(axis.title.y = element_text(size = 18, vjust = 1.5)) +
    annotate("segment", x = -Inf, xend = Inf, y = -Inf, yend = -Inf) +
    annotate("segment", x = -Inf, xend = -Inf, y = -Inf, yend = Inf) +
    theme(axis.text.x = element_text(color = c("black", "black", "black", "black", "black", "black", "darkblue", "darkblue"), size = 15),
    axis.text.y = element_text(color = "black", size = 15)) + 
    stat_summary(fun.data = mean_cl_boot, geom = "errorbar", colour = "black") + 
    stat_summary(fun = mean, geom = "point", size = 2, shape = 21, fill = "white", colour = "black")

bp.fi.mx

rs.mn.y <- expression("Minimum Rate of Spread ( m"~min^-1~")")

bp.rs.mn <- data %>%
    ggplot(aes(x = LCP, y = ROSmin, fill = Moisture)) +
#    geom_boxplot(fill = "black") +
    scale_fill_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    scale_color_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    #geom_half_point(aes(fill = Type), shape = 21, size = 2, side = "l") +
    geom_violin(aes(fill = Moisture), color = "black", alpha = 0.8 ) +
#    scale_color_brewer(palette = "Dark2") +
#    scale_fill_brewer(palette = "Dark2") +
    theme(panel.background = element_blank()) +
#    theme(legend.key = element_blank()) +
#    theme(legend.title = element_blank()) +
    xlab("Experimental Landscape") +
    ylab(rs.mn.y) +
    labs(color = "", fill = "") +
#    ggtitle("\nMean Rate of Spread") +
    facet_grid(Moisture~Wind, labeller = label_both) +
    theme(legend.position = "bottom", legend.text = element_text(size = 15), legend.key.spacing = unit(10, "pt")) +
    theme(panel.grid.major = element_line(colour = "grey")) +
    theme(strip.background = element_rect(fill = "white")) +
    theme(strip.text = element_text(size = 16)) +
    #theme(plot.title = element_text(size = 30, face = "bold", hjust = 0.5, vjust = 1)) +
    theme(axis.title.x = element_text(size = 18, vjust = -0.5)) +
    theme(axis.title.y = element_text(size = 18, vjust = 1.5)) +
    annotate("segment", x = -Inf, xend = Inf, y = -Inf, yend = -Inf) +
    annotate("segment", x = -Inf, xend = -Inf, y = -Inf, yend = Inf) +
    theme(axis.text.x = element_text(color = c("black", "black", "black", "black", "black", "black", "darkblue", "darkblue"), size = 15),
    axis.text.y = element_text(color = "black", size = 15)) + 
    stat_summary(fun.data = mean_cl_boot, geom = "errorbar", colour = "black") + 
    stat_summary(fun = mean, geom = "point", size = 2, shape = 21, fill = "white", colour = "black")

bp.rs.mn

fi.mn.y <- expression("Minimum Fireline Intensity ( kw"~m^-1~")")

bp.fi.mn <- data %>%
    ggplot(aes(x = LCP, y = FImin, fill = Moisture)) +
#    geom_boxplot(fill = "black") +
    scale_fill_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    scale_color_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    #geom_half_point(aes(fill = Type), shape = 21, size = 2, side = "l") +
    geom_violin(aes(fill = Moisture), color = "black", alpha = 0.8 ) +
#    scale_color_brewer(palette = "Dark2") +
#    scale_fill_brewer(palette = "Dark2") +
    theme(panel.background = element_blank()) +
#    theme(legend.key = element_blank()) +
#    theme(legend.title = element_blank()) +
    xlab("Experimental Landscape") +
    ylab(fi.mn.y) +
    labs(color = "", fill = "") +
#    ggtitle("\nMean Rate of Spread") +
    facet_grid(Moisture~Wind, labeller = label_both) +
    theme(legend.position = "bottom", legend.text = element_text(size = 15), legend.key.spacing = unit(10, "pt")) +
    theme(panel.grid.major = element_line(colour = "grey")) +
    theme(strip.background = element_rect(fill = "white")) +
    theme(strip.text = element_text(size = 16)) +
    #theme(plot.title = element_text(size = 30, face = "bold", hjust = 0.5, vjust = 1)) +
    theme(axis.title.x = element_text(size = 18, vjust = -0.5)) +
    theme(axis.title.y = element_text(size = 18, vjust = 1.5)) +
    annotate("segment", x = -Inf, xend = Inf, y = -Inf, yend = -Inf) +
    annotate("segment", x = -Inf, xend = -Inf, y = -Inf, yend = Inf) +
    theme(axis.text.x = element_text(color = c("black", "black", "black", "black", "black", "black", "darkblue", "darkblue"), size = 15),
    axis.text.y = element_text(color = "black", size = 15)) + 
    stat_summary(fun.data = mean_cl_boot, geom = "errorbar", colour = "black") + 
    stat_summary(fun = mean, geom = "point", size = 2, shape = 21, fill = "white", colour = "black")

bp.fi.mn

rs.sd.y <- expression("Standard Deviation Rate of Spread ( m"~min^-1~")")

bp.rs.sd <- data %>%
    ggplot(aes(x = LCP, y = ROSstd, fill = Moisture)) +
#    geom_boxplot(fill = "black") +
    coord_cartesian(ylim = c(0, 2.85)) +
    scale_fill_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    scale_color_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    #geom_half_point(aes(fill = Type), shape = 21, size = 2, side = "l") +
    geom_violin(aes(fill = Moisture), color = "black", alpha = 0.8 ) +
#    scale_color_brewer(palette = "Dark2") +
#    scale_fill_brewer(palette = "Dark2") +
    theme(panel.background = element_blank()) +
#    theme(legend.key = element_blank()) +
#    theme(legend.title = element_blank()) +
    xlab("Experimental Landscape") +
    ylab(rs.sd.y) +
    labs(color = "", fill = "") +
#    ggtitle("\nMean Rate of Spread") +
    facet_grid(Moisture~Wind, labeller = label_both) +
    theme(legend.position = "bottom", legend.text = element_text(size = 15), legend.key.spacing = unit(10, "pt")) +
    theme(panel.grid.major = element_line(colour = "grey")) +
    theme(strip.background = element_rect(fill = "white")) +
    theme(strip.text = element_text(size = 16)) +
    #theme(plot.title = element_text(size = 30, face = "bold", hjust = 0.5, vjust = 1)) +
    theme(axis.title.x = element_text(size = 18, vjust = -0.5)) +
    theme(axis.title.y = element_text(size = 18, vjust = 1.5)) +
    annotate("segment", x = -Inf, xend = Inf, y = -Inf, yend = -Inf) +
    annotate("segment", x = -Inf, xend = -Inf, y = -Inf, yend = Inf) +
    theme(axis.text.x = element_text(color = c("black", "black", "black", "black", "black", "black", "darkblue", "darkblue"), size = 15),
    axis.text.y = element_text(color = "black", size = 15)) + 
    stat_summary(fun.data = mean_cl_boot, geom = "errorbar", colour = "black") + 
    stat_summary(fun = mean, geom = "point", size = 2, shape = 21, fill = "white", colour = "black") + 
    stat_summary(fun = max, colour = "white", size = 10, geom = "point", aes(y = max(ROSstd+0.19), x = LCP), show.legend = FALSE) +
    stat_summary(geom = "text", fun = max, label =
    c("B", "D", "BC", "B", "A", "B", "B", "C", 
    "A", "C", "AB", "AB", "A", "B", "AB", "C", 
    "AB", "E", "CD", "BC", "A", "BC", "C", "D",
    "A", "C", "B", "B", "AB", "B", "AB", "D", 
    "B", "E", "BC", "B", "A", "B", "D", "CD", 
    "A", "C", "AB", "AB", "A", "AB", "B", "D"),
    aes(y = max(ROSstd+0.19), x = LCP), position = "identity", colour = "red", size = 5)

bp.rs.sd

fi.sd.y <- expression("Standard Deviation Fireline Intensity ( kw"~m^-1~")")

bp.fi.sd <- data %>%
    ggplot(aes(x = LCP, y = FIstd, fill = Moisture)) +
#    geom_boxplot(fill = "black") +
    coord_cartesian(ylim = c(0, 2250)) +
    scale_fill_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    scale_color_manual(values = c("#E85362ff", "#952c80ff", "#400f73ff", "black", "black"), labels = c("High Risk", "Moderate Risk", "Low Risk")) +
    #geom_half_point(aes(fill = Type), shape = 21, size = 2, side = "l") +
    geom_violin(aes(fill = Moisture), color = "black", alpha = 0.8 ) +
#    scale_color_brewer(palette = "Dark2") +
#    scale_fill_brewer(palette = "Dark2") +
    theme(panel.background = element_blank()) +
#    theme(legend.key = element_blank()) +
#    theme(legend.title = element_blank()) +
    xlab("Experimental Landscape") +
    ylab(fi.sd.y) +
    labs(color = "", fill = "") +
#    ggtitle("\nMean Rate of Spread") +
    facet_grid(Moisture~Wind, labeller = label_both) +
    theme(legend.position = "bottom", legend.text = element_text(size = 15), legend.key.spacing = unit(10, "pt")) +
    theme(panel.grid.major = element_line(colour = "grey")) +
    theme(strip.background = element_rect(fill = "white")) +
    theme(strip.text = element_text(size = 16)) +
    #theme(plot.title = element_text(size = 30, face = "bold", hjust = 0.5, vjust = 1)) +
    theme(axis.title.x = element_text(size = 18, vjust = -0.5)) +
    theme(axis.title.y = element_text(size = 18, vjust = 1.5)) +
    annotate("segment", x = -Inf, xend = Inf, y = -Inf, yend = -Inf) +
    annotate("segment", x = -Inf, xend = -Inf, y = -Inf, yend = Inf) +
    theme(axis.text.x = element_text(color = c("black", "black", "black", "black", "black", "black", "darkblue", "darkblue"), size = 15),
    axis.text.y = element_text(color = "black", size = 15)) + 
    stat_summary(fun.data = mean_cl_boot, geom = "errorbar", colour = "black") + 
    stat_summary(fun = mean, geom = "point", size = 2, shape = 21, fill = "white", colour = "black") + 
    stat_summary(fun = max, colour = "white", size = 10, geom = "point", aes(y = max(FIstd+260), x = LCP), show.legend = FALSE) +
    stat_summary(geom = "text", fun = max, label = 
    c("B", "D", "BC", "B", "A", "BC", "BC", "C", 
    "AB", "D", "ABC", "ABC", "A", "C", "BC", "D", 
    "B", "D", "BC", "B", "A", "B", "BC", "C",
    "AB", "C", "AB", "AB", "A", "B", "B", "C", 
    "B", "E", "BC", "B", "A", "B", "D", "C", 
    "AB", "D", "AB", "AB", "A", "BC", "C", "D"),
    aes(y = max(FIstd+260), x = LCP), position = "identity", colour = "red", size = 5)

bp.fi.sd
